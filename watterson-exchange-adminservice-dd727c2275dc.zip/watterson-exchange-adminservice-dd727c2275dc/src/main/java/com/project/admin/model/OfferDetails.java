package com.project.admin.model;

public class OfferDetails {

	private String activityDate;
	private String offerSubmit;
	private String offerTrade;
	private String offerDelete;
	private String offerActive;
	
	
	public String getActivityDate() {
		return activityDate;
	}
	public void setActivityDate(String activityDate) {
		this.activityDate = activityDate;
	}
	public String getOfferSubmit() {
		return offerSubmit;
	}
	public void setOfferSubmit(String offerSubmit) {
		this.offerSubmit = offerSubmit;
	}
	public String getOfferTrade() {
		return offerTrade;
	}
	public void setOfferTrade(String offerTrade) {
		this.offerTrade = offerTrade;
	}
	public String getOfferDelete() {
		return offerDelete;
	}
	public void setOfferDelete(String offerDelete) {
		this.offerDelete = offerDelete;
	}
	public String getOfferActive() {
		return offerActive;
	}
	public void setOfferActive(String offerActive) {
		this.offerActive = offerActive;
	}
	
	
}
