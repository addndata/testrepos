package com.project.admin.model;

public class CustomerLedger {

	private int TransactionID;
	private String customer_ID;
	private String customer_name;
	private String btc_balance;
	private String eth_balance;
	private String bch_balance;
	private String hcx_balance;
	private String iec_balance;
	private String ltc_balance;
	private String diam_balance;
	private String fiat_balance;
	private String bsv_balance;
	private String etc_balance;
	
	public int getTransactionID() {
		return TransactionID;
	}
	public void setTransactionID(int transactionID) {
		TransactionID = transactionID;
	}
	public String getCustomer_ID() {
		return customer_ID;
	}
	public void setCustomer_ID(String customer_ID) {
		this.customer_ID = customer_ID;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getBtc_balance() {
		return btc_balance;
	}
	public void setBtc_balance(String btc_balance) {
		this.btc_balance = btc_balance;
	}	
	public String getEth_balance() {
		return eth_balance;
	}
	public void setEth_balance(String eth_balance) {
		this.eth_balance = eth_balance;
	}
	public String getBch_balance() {
		return bch_balance;
	}
	public void setBch_balance(String bch_balance) {
		this.bch_balance = bch_balance;
	}	
	public String getHcx_balance() {
		return hcx_balance;
	}
	public void setHcx_balance(String hcx_balance) {
		this.hcx_balance = hcx_balance;
	}
	public String getIec_balance() {
		return iec_balance;
	}
	public void setIec_balance(String iec_balance) {
		this.iec_balance = iec_balance;
	}
	public String getLtc_balance() {
		return ltc_balance;
	}
	public void setLtc_balance(String ltc_balance) {
		this.ltc_balance = ltc_balance;
	}
	public String getDiam_balance() {
		return diam_balance;
	}
	public void setDiam_balance(String diam_balance) {
		this.diam_balance = diam_balance;
	}
	public String getFiat_balance() {
		return fiat_balance;
	}
	public void setFiat_balance(String fiat_balance) {
		this.fiat_balance = fiat_balance;
	}
	public String getBsv_balance() {
		return bsv_balance;
	}
	public void setBsv_balance(String bsv_balance) {
		this.bsv_balance = bsv_balance;
	}
	public String getEtc_balance() {
		return etc_balance;
	}
	public void setEtc_balance(String etc_balance) {
		this.etc_balance = etc_balance;
	}
	
	
}
