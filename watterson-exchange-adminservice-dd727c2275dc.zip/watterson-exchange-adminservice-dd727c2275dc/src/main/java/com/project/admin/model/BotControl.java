package com.project.admin.model;

public class BotControl {

	private double spradeValue ;

	public double getSpradeValue() {
		return spradeValue;
	}

	public void setSpradeValue(double spradeValue) {
		this.spradeValue = spradeValue;
	}
	
	
}
