package com.project.admin.model;

public class ContractDetails {
	private int baseCurrencyId;
	private String assetPair;
	private int assetCode;
	
	public int getBaseCurrencyId() {
		return baseCurrencyId;
	}
	public void setBaseCurrencyId(int baseCurrencyId) {
		this.baseCurrencyId = baseCurrencyId;
	}
	public String getAssetPair() {
		return assetPair;
	}
	public void setAssetPair(String assetPair) {
		this.assetPair = assetPair;
	}
	public int getAssetCode() {
		return assetCode;
	}
	public void setAssetCode(int assetCode) {
		this.assetCode = assetCode;
	}
	
}
