package com.project.admin.model;

public class DesignationMaster {

	private int dsgn_id;
	private String dsgn_name;
	private String created_no;
	private int dsgn_status;
	
	public int getDsgn_id() {
		return dsgn_id;
	}
	public void setDsgn_id(int dsgn_id) {
		this.dsgn_id = dsgn_id;
	}
	public String getDsgn_name() {
		return dsgn_name;
	}
	public void setDsgn_name(String dsgn_name) {
		this.dsgn_name = dsgn_name;
	}
	public String getCreated_no() {
		return created_no;
	}
	public void setCreated_no(String created_no) {
		this.created_no = created_no;
	}
	public int getDsgn_status() {
		return dsgn_status;
	}
	public void setDsgn_status(int dsgn_status) {
		this.dsgn_status = dsgn_status;
	}
	
	
}
